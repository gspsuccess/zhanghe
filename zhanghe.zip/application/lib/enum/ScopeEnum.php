<?php
/**
 * Created by PhpStorm.
 * User: gongs
 * Date: 2017/6/12
 * Time: 17:18
 */

namespace app\lib\enum;


class ScopeEnum
{
    const User = 16;
    const Super = 32;
}