<?php
/**
 * Created by PhpStorm.
 * User: gongs
 * Date: 2017/6/12
 * Time: 11:36
 */

namespace app\lib\exception;


class WeChatException extends BaseException
{

}