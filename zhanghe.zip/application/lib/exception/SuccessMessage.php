<?php
/**
 * Created by PhpStorm.
 * User: gongs
 * Date: 2017/6/12
 * Time: 16:28
 */

namespace app\lib\exception;


class SuccessMessage
{
    public $code = 201;
    public $msg = 'ok';
    public $errorCode = 0;
}