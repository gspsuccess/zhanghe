<?php
/**
 * Created by PhpStorm.
 * User: ZNZG
 * Date: 2018/10/23
 * Time: 12:00
 */

namespace app\index\controller;


class Waters extends Base
{
    public function show()
    {

    }

    public function remove()
    {

    }
}