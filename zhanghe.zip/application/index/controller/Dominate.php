<?php
/**
 * Created by PhpStorm.
 * User: ZNZG
 * Date: 2018/9/19
 * Time: 16:04
 */

namespace app\index\controller;


class Dominate extends Base
{
    public function index()
    {
        $this->assign('title','配水计划记录');
        return $this->fetch();
    }

    public function add()
    {
        $this->assign('title','新增配水计划');
        return $this->fetch();
    }
}