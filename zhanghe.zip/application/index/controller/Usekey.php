<?php
/**
 * Created by PhpStorm.
 * User: ZNZG
 * Date: 2018/9/19
 * Time: 15:04
 */

namespace app\index\controller;


class Usekey extends Base
{
    public function index()
    {
        return $this->fetch();
    }
}