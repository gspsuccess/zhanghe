<?php
/**
 * Created by PhpStorm.
 * User: ZNZG
 * Date: 2018/10/22
 * Time: 20:14
 */

namespace app\index\controller;

use app\index\model\User as UserModel;
use app\index\model\Subcribe as SubcribeModel;


class Subcribe extends Base
{
    public function index()
    {
        if(request()->isGet())
        {
            $users = UserModel::getAll();
            $users_select = create_select($users, 0, 'id', 'realname');

            $this->assign('users_select', $users_select);
            $this->assign('title', '用水申报记录');
            return $this->fetch();
        }
        else
        {
            $subcribe = new SubcribeModel();
            $post = input('post.');
            $offset = empty($post['offset'])?0:$post['offset'];
            $pagesize = empty($post['pagesize'])?10:$post['pagesize'];

            $map = [];
            if(!empty($post['name']))
            {
                $map[] = ['title','like','%'.$post['name'].'%'];
            }

            $infolist = $subcribe
                ->where($map)
                ->limit($offset,$pagesize)
                ->order('id desc')
                ->with('user')
                ->select();

            $total = $subcribe->where($map)->count();

            $result = [
                'total'=>$total,
                'rows'=>$infolist
            ];

            return json($result);
        }
    }

    public function add()
    {
        $users = UserModel::getAll();
        $users_select = create_select($users,0,'id','realname');

        $this->assign('users_select',$users_select);
        $this->assign('title','新增用水申报');
        return $this->fetch();
    }
}