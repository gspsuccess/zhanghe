<?php
/**
 * Created by PhpStorm.
 * User: ZNZG
 * Date: 2018/9/27
 * Time: 11:35
 */

namespace app\index\model;


class LoginRecord extends Base
{
    protected $table = 'login_records';
}