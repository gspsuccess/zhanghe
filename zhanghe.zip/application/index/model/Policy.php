<?php
/**
 * Created by PhpStorm.
 * User: ZNZG
 * Date: 2018/10/23
 * Time: 11:46
 */

namespace app\index\model;


class Policy extends Base
{
    protected $table = 'policies';
    protected $autoWriteTimestamp = true;
}