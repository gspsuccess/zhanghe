<?php
/**
 * Created by PhpStorm.
 * User: ZNZG
 * Date: 2018/10/5
 * Time: 18:17
 */

namespace app\index\model;


class Privilege extends Base
{
    protected $table = 'think_auth_rule';
}