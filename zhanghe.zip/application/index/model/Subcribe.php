<?php
/**
 * Created by PhpStorm.
 * User: ZNZG
 * Date: 2018/9/21
 * Time: 16:50
 */

namespace app\index\model;


class Subcribe extends Base
{
    protected $table = 'subcribes';
    protected $autoWriteTimestamp = true;

    /**
     * 与用户进行关联
     * @return \think\model\relation\BelongsTo
     */
    public function user()
    {
        return $this->belongsTo('user');
    }
}