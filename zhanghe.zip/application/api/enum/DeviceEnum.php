<?php
/**
 * Created by PhpStorm.
 * User: ZNZG
 * Date: 2018/10/18
 * Time: 14:03
 */

namespace app\api\enum;


class DeviceEnum
{
    const START = 1;
    const STOP = 0;
}