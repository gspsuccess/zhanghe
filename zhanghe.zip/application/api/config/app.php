<?php
/**
 * Created by PhpStorm.
 * User: ZNZG
 * Date: 2018/9/26
 * Time: 11:59
 */

return [
    'default_return_type'    => 'json',
];