<?php
/**
 * Created by PhpStorm.
 * User: ZNZG
 * Date: 2018/9/26
 * Time: 15:44
 */

namespace app\api\controller\v1;


use think\Controller;

class Base extends Controller
{

}