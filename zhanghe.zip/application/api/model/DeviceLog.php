<?php
/**
 * Created by PhpStorm.
 * User: ZNZG
 * Date: 2018/10/18
 * Time: 12:25
 */

namespace app\api\model;


class DeviceLog extends Base
{
    protected $table = 'device_logs';
    protected $autoWriteTimestamp = true;
}