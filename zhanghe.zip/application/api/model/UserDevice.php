<?php
/**
 * Created by PhpStorm.
 * User: ZNZG
 * Date: 2018/10/10
 * Time: 11:50
 */

namespace app\api\model;


class UserDevice extends Base
{
    protected $table = 'user_device_relations';
}