<?php
/**
 * Created by PhpStorm.
 * User: ZNZG
 * Date: 2018/10/9
 * Time: 14:25
 */

namespace app\api\model;


class NoticeUser extends Base
{
    protected $table = 'notice_user_relations';
    protected $autoWriteTimestamp = true;
}