<?php

namespace app\http\middleware;

class Check
{
    public function handle($request, \Closure $next)
    {
        $response = $next($request);

        return $response;
    }
}
