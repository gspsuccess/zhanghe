<?php /*a:3:{s:62:"D:\xampp\htdocs\zhanghe\application\index\view\wprice\add.html";i:1540211649;s:65:"D:\xampp\htdocs\zhanghe\application\index\view\layout\layout.html";i:1539172169;s:63:"D:\xampp\htdocs\zhanghe\application\index\view\common\menu.html";i:1540198745;}*/ ?>
<!DOCTYPE html>
<html xmlns="http://www.w3.org/1999/xhtml">
<head>
    <meta charset="utf-8"/>
    <meta name="viewport" content="width=device-width, initial-scale=1.0"/>
    <title><?php echo htmlentities($title); ?></title>
    <link href="https://fonts.googleapis.com/icon?family=Material+Icons" rel="stylesheet">
    <link rel="stylesheet" href="/assets/materialize/css/materialize.min.css" media="screen,projection"/>
    <link href="/assets/css/font-awesome.css" rel="stylesheet"/>
    <link href="/assets/css/bootstrap.css" rel="stylesheet"/>
    <link href="/assets/css/custom-styles.css" rel="stylesheet"/>
    <link href="/assets/component/strap-table/bootstrap-table.min.css" rel="stylesheet">
    <link href="/assets/component/strap-datetime/bootstrap-datetimepicker.min.css" rel="stylesheet">
    <link href="/assets/component/zTree/zTreeStyle.css" rel="stylesheet">

    <script src="/assets/js/jquery-1.12.4.min.js"></script>
    <script src="/assets/js/bootstrap.min.js"></script>
    <script src="/assets/js/custom/common.js"></script>

    <script type="text/javascript" src="/assets/component/zTree/jquery.ztree.core-3.5.js"></script>
    <script type="text/javascript" src="/assets/component/zTree/jquery.ztree.excheck-3.5.js"></script>
    <script type="text/javascript" src="/assets/component/zTree/jquery.ztree.exedit-3.5.js"></script>
</head>
<body>
<nav class="navbar navbar-default top-navbar" role="navigation">
    <div class="navbar-header">
        <button type="button" class="navbar-toggle waves-effect waves-dark" data-toggle="collapse"
                data-target=".sidebar-collapse">
            <span class="sr-only">Toggle navigation</span>
            <span class="icon-bar"></span>
            <span class="icon-bar"></span>
            <span class="icon-bar"></span>
        </button>
        <a class="navbar-brand waves-effect waves-dark" href="/">
            <strong>水费征收管理系统</strong></a>

        <div id="sideNav" href=""><i class="material-icons dp48">toc</i></div>
    </div>

    <ul class="nav navbar-top-links navbar-right">
        <li><a class="dropdown-button waves-effect waves-dark" href="#!" data-activates="dropdown4"><i
                class="fa fa-envelope fa-fw"></i> <i class="material-icons right">arrow_drop_down</i></a></li>
        <li><a class="dropdown-button waves-effect waves-dark" href="#!" data-activates="dropdown2"><i
                class="fa fa-bell fa-fw"></i> <i class="material-icons right">arrow_drop_down</i></a></li>
        <li><a class="dropdown-button waves-effect waves-dark" href="#!" data-activates="dropdown1"><i
                class="fa fa-user fa-fw"></i> <b><?php echo htmlentities($username); ?></b> <i
                class="material-icons right">arrow_drop_down</i></a></li>
    </ul>
</nav>
<!-- Dropdown Structure -->
<ul id="dropdown1" class="dropdown-content">
    <li><a href="#"><i class="fa fa-gear fa-fw"></i>信息设置</a>
    </li>
    <li><a onclick="return confirm('确定退出吗？')" href="/index/login/logout"><i class="fa fa-sign-out fa-fw"></i>退出登录</a>
    </li>
</ul>
<ul id="dropdown2" class="dropdown-content w250">
    <li>
        <div>
            <i class="fa fa-comment fa-fw"></i> New Comment
            <span class="pull-right text-muted small">4 min</span>
        </div>
        </a>
    </li>
    <li class="divider"></li>
    <li>
        <div>
            <i class="fa fa-twitter fa-fw"></i> 3 New Followers
            <span class="pull-right text-muted small">12 min</span>
        </div>
        </a>
    </li>
    <li class="divider"></li>
    <li>
        <div>
            <i class="fa fa-envelope fa-fw"></i> Message Sent
            <span class="pull-right text-muted small">4 min</span>
        </div>
        </a>
    </li>
    <li class="divider"></li>
    <li>
        <div>
            <i class="fa fa-tasks fa-fw"></i> New Task
            <span class="pull-right text-muted small">4 min</span>
        </div>
        </a>
    </li>
    <li class="divider"></li>
    <li>
        <div>
            <i class="fa fa-upload fa-fw"></i> Server Rebooted
            <span class="pull-right text-muted small">4 min</span>
        </div>
        </a>
    </li>
    <li class="divider"></li>
    <li>
        <a class="text-center" href="#">
            <strong>See All Alerts</strong>
            <i class="fa fa-angle-right"></i>
        </a>
    </li>
</ul>
<ul id="dropdown4" class="dropdown-content dropdown-tasks w250 taskList">
    <li>
        <div>
            <strong>John Doe</strong>
                                    <span class="pull-right text-muted">
                                        <em>Today</em>
                                    </span>
        </div>
        <p>Lorem Ipsum has been the industry's standard dummy text ever since the 1500s...</p>
        </a>
    </li>
    <li class="divider"></li>
    <li>
        <div>
            <strong>John Smith</strong>
                                    <span class="pull-right text-muted">
                                        <em>Yesterday</em>
                                    </span>
        </div>
        <p>Lorem Ipsum has been the industry's standard dummy text ever since an kwilnw...</p>
        </a>
    </li>
    <li class="divider"></li>
    <li>
        <a href="#">
            <div>
                <strong>John Smith</strong>
                                    <span class="pull-right text-muted">
                                        <em>Yesterday</em>
                                    </span>
            </div>
            <p>Lorem Ipsum has been the industry's standard dummy text ever since the...</p>
        </a>
    </li>
    <li class="divider"></li>
    <li>
        <a class="text-center" href="#">
            <strong>Read All Messages</strong>
            <i class="fa fa-angle-right"></i>
        </a>
    </li>
</ul>
<!--/. NAV TOP  -->
<nav class="navbar-default navbar-side" role="navigation">
    <div class="sidebar-collapse">
        <ul class="nav" id="main-menu">
            <?php foreach($menu as $k => $v): ?>
            <li<?php if($v['active']): ?> class="active-menu active"<?php endif; ?>>
                <a class="<?php if($v['active']): ?> active-menu"<?php endif; ?>waves-effect waves-dark" href="<?php echo htmlentities($v['name']); ?>"><i class="<?php echo htmlentities($v['style']); ?>"></i>
                    <?php echo htmlentities($v['title']); ?><span
                            class="fa arrow"></span></a>
                <?php if(!empty($v['sub'])): ?>
                <ul class="nav nav-second-level">
                    <?php foreach($v['sub'] as $kitem => $vitem): ?>
                    <li>
                        <a<?php if($vitem['active']): ?> class="active-menu"<?php endif; ?> href="/<?php echo htmlentities($vitem['name']); ?>"><?php echo htmlentities($vitem['title']); ?></a>
                    </li>
                    <?php endforeach; ?>
                </ul>
            <?php endif; ?>
            </li>
            <?php endforeach; ?>
        </ul>
    </div>
</nav>
<!-- /. NAV SIDE  -->
<div id="wrapper">
    <div id="page-wrapper">
        <div class="header">
            <h1 class="page-header">
                Dashboard
            </h1>
            <ol class="breadcrumb">
                <li><a href="#">Home</a></li>
                <li><a href="#">Dashboard</a></li>
                <li class="active">Data</li>
            </ol>
        </div>
        <div class="inner">
             新增阶梯水价
        </div>
    </div>
</div>

<!-- Bootstrap Js -->
<script src="/assets/component/strap-table/bootstrap-table.min.js"></script>
<script src="/assets/component/strap-table/bootstrap-table-zh-CN.min.js"></script>
<script src="/assets/component/strap-datetime/bootstrap-datetimepicker.min.js"></script>
<script src="/assets/js/jquery.metisMenu.js"></script>
<script src="/assets/materialize/js/materialize.min.js"></script>

<!-- Custom Js -->
<script src="/assets/js/custom-scripts.js"></script>
<script src="/assets/js/bootstrapValidator.min.js"></script>
<script src="/assets/js/layer/layer.js"></script>
</body>
</html>