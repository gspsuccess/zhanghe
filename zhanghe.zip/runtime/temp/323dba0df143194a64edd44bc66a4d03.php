<?php /*a:3:{s:66:"D:\xampp\htdocs\zhanghe\application\index\view\index\settings.html";i:1537676351;s:65:"D:\xampp\htdocs\zhanghe\application\index\view\layout\layout.html";i:1539172169;s:63:"D:\xampp\htdocs\zhanghe\application\index\view\common\menu.html";i:1540198745;}*/ ?>
<!DOCTYPE html>
<html xmlns="http://www.w3.org/1999/xhtml">
<head>
    <meta charset="utf-8"/>
    <meta name="viewport" content="width=device-width, initial-scale=1.0"/>
    <title><?php echo htmlentities($title); ?></title>
    <link href="https://fonts.googleapis.com/icon?family=Material+Icons" rel="stylesheet">
    <link rel="stylesheet" href="/assets/materialize/css/materialize.min.css" media="screen,projection"/>
    <link href="/assets/css/font-awesome.css" rel="stylesheet"/>
    <link href="/assets/css/bootstrap.css" rel="stylesheet"/>
    <link href="/assets/css/custom-styles.css" rel="stylesheet"/>
    <link href="/assets/component/strap-table/bootstrap-table.min.css" rel="stylesheet">
    <link href="/assets/component/strap-datetime/bootstrap-datetimepicker.min.css" rel="stylesheet">
    <link href="/assets/component/zTree/zTreeStyle.css" rel="stylesheet">

    <script src="/assets/js/jquery-1.12.4.min.js"></script>
    <script src="/assets/js/bootstrap.min.js"></script>
    <script src="/assets/js/custom/common.js"></script>

    <script type="text/javascript" src="/assets/component/zTree/jquery.ztree.core-3.5.js"></script>
    <script type="text/javascript" src="/assets/component/zTree/jquery.ztree.excheck-3.5.js"></script>
    <script type="text/javascript" src="/assets/component/zTree/jquery.ztree.exedit-3.5.js"></script>
</head>
<body>
<nav class="navbar navbar-default top-navbar" role="navigation">
    <div class="navbar-header">
        <button type="button" class="navbar-toggle waves-effect waves-dark" data-toggle="collapse"
                data-target=".sidebar-collapse">
            <span class="sr-only">Toggle navigation</span>
            <span class="icon-bar"></span>
            <span class="icon-bar"></span>
            <span class="icon-bar"></span>
        </button>
        <a class="navbar-brand waves-effect waves-dark" href="/">
            <strong>水费征收管理系统</strong></a>

        <div id="sideNav" href=""><i class="material-icons dp48">toc</i></div>
    </div>

    <ul class="nav navbar-top-links navbar-right">
        <li><a class="dropdown-button waves-effect waves-dark" href="#!" data-activates="dropdown4"><i
                class="fa fa-envelope fa-fw"></i> <i class="material-icons right">arrow_drop_down</i></a></li>
        <li><a class="dropdown-button waves-effect waves-dark" href="#!" data-activates="dropdown2"><i
                class="fa fa-bell fa-fw"></i> <i class="material-icons right">arrow_drop_down</i></a></li>
        <li><a class="dropdown-button waves-effect waves-dark" href="#!" data-activates="dropdown1"><i
                class="fa fa-user fa-fw"></i> <b><?php echo htmlentities($username); ?></b> <i
                class="material-icons right">arrow_drop_down</i></a></li>
    </ul>
</nav>
<!-- Dropdown Structure -->
<ul id="dropdown1" class="dropdown-content">
    <li><a href="#"><i class="fa fa-gear fa-fw"></i>信息设置</a>
    </li>
    <li><a onclick="return confirm('确定退出吗？')" href="/index/login/logout"><i class="fa fa-sign-out fa-fw"></i>退出登录</a>
    </li>
</ul>
<ul id="dropdown2" class="dropdown-content w250">
    <li>
        <div>
            <i class="fa fa-comment fa-fw"></i> New Comment
            <span class="pull-right text-muted small">4 min</span>
        </div>
        </a>
    </li>
    <li class="divider"></li>
    <li>
        <div>
            <i class="fa fa-twitter fa-fw"></i> 3 New Followers
            <span class="pull-right text-muted small">12 min</span>
        </div>
        </a>
    </li>
    <li class="divider"></li>
    <li>
        <div>
            <i class="fa fa-envelope fa-fw"></i> Message Sent
            <span class="pull-right text-muted small">4 min</span>
        </div>
        </a>
    </li>
    <li class="divider"></li>
    <li>
        <div>
            <i class="fa fa-tasks fa-fw"></i> New Task
            <span class="pull-right text-muted small">4 min</span>
        </div>
        </a>
    </li>
    <li class="divider"></li>
    <li>
        <div>
            <i class="fa fa-upload fa-fw"></i> Server Rebooted
            <span class="pull-right text-muted small">4 min</span>
        </div>
        </a>
    </li>
    <li class="divider"></li>
    <li>
        <a class="text-center" href="#">
            <strong>See All Alerts</strong>
            <i class="fa fa-angle-right"></i>
        </a>
    </li>
</ul>
<ul id="dropdown4" class="dropdown-content dropdown-tasks w250 taskList">
    <li>
        <div>
            <strong>John Doe</strong>
                                    <span class="pull-right text-muted">
                                        <em>Today</em>
                                    </span>
        </div>
        <p>Lorem Ipsum has been the industry's standard dummy text ever since the 1500s...</p>
        </a>
    </li>
    <li class="divider"></li>
    <li>
        <div>
            <strong>John Smith</strong>
                                    <span class="pull-right text-muted">
                                        <em>Yesterday</em>
                                    </span>
        </div>
        <p>Lorem Ipsum has been the industry's standard dummy text ever since an kwilnw...</p>
        </a>
    </li>
    <li class="divider"></li>
    <li>
        <a href="#">
            <div>
                <strong>John Smith</strong>
                                    <span class="pull-right text-muted">
                                        <em>Yesterday</em>
                                    </span>
            </div>
            <p>Lorem Ipsum has been the industry's standard dummy text ever since the...</p>
        </a>
    </li>
    <li class="divider"></li>
    <li>
        <a class="text-center" href="#">
            <strong>Read All Messages</strong>
            <i class="fa fa-angle-right"></i>
        </a>
    </li>
</ul>
<!--/. NAV TOP  -->
<nav class="navbar-default navbar-side" role="navigation">
    <div class="sidebar-collapse">
        <ul class="nav" id="main-menu">
            <?php foreach($menu as $k => $v): ?>
            <li<?php if($v['active']): ?> class="active-menu active"<?php endif; ?>>
                <a class="<?php if($v['active']): ?> active-menu"<?php endif; ?>waves-effect waves-dark" href="<?php echo htmlentities($v['name']); ?>"><i class="<?php echo htmlentities($v['style']); ?>"></i>
                    <?php echo htmlentities($v['title']); ?><span
                            class="fa arrow"></span></a>
                <?php if(!empty($v['sub'])): ?>
                <ul class="nav nav-second-level">
                    <?php foreach($v['sub'] as $kitem => $vitem): ?>
                    <li>
                        <a<?php if($vitem['active']): ?> class="active-menu"<?php endif; ?> href="/<?php echo htmlentities($vitem['name']); ?>"><?php echo htmlentities($vitem['title']); ?></a>
                    </li>
                    <?php endforeach; ?>
                </ul>
            <?php endif; ?>
            </li>
            <?php endforeach; ?>
        </ul>
    </div>
</nav>
<!-- /. NAV SIDE  -->
<div id="wrapper">
    <div id="page-wrapper">
        <div class="header">
            <h1 class="page-header">
                初始化参数
            </h1>
            <ol class="breadcrumb">
                <li>当前位置：</li>
                <li><a href="#">首页</a></li>
                <li><a href="#">系统设置</a></li>
                <li class="active">初始化参数</li>
            </ol>
        </div>
        <div class="inner">
            <table id="table">

            </table>
        </div>
    </div>
</div>
<script>
    $("#table").bootstrapTable({ // 对应table标签的id
        url: "/index/project/index", // 获取表格数据的url
        method:'post',
        cache: false, // 设置为 false 禁用 AJAX 数据缓存， 默认为true
        striped: true,  //表格显示条纹，默认为false
        pagination: true, // 在表格底部显示分页组件，默认false
        pageList: [10, 20], // 设置页面可以显示的数据条数
        pageSize: 10, // 页面数据条数
        pageNumber: 1, // 首页页码
        sidePagination: 'server', // 设置为服务器端分页
        rowStyle:function(row,index){
            var strclass = {};
            if(row.all<=100){
                strclass = 'success';
            }
            else if(301<=row.all){
                strclass = 'info';
            }
            else if(100<row.all<=300){
                strclass = 'active';
            }

            return { classes: strclass};
        },
        queryParams: function (params) { // 请求服务器数据时发送的参数，可以在这里添加额外的查询参数，返回false则终止请求

            return {
                pageSize: params.limit, // 每页要显示的数据条数
                offset: params.offset, // 每页显示数据的开始行号
                sort: params.sort, // 要排序的字段
                sortOrder: params.order, // 排序规则
                dataId: $("#dataId").val() // 额外添加的参数
            }
        },
        sortName: 'id', // 要排序的字段
        sortOrder: 'desc', // 排序规则
        columns: [
            {
                checkbox: true, // 显示一个勾选框
                align: 'center' // 居中显示
            }, {
                field: 'id', // 返回json数据中的name
                title: '编号', // 表格表头显示文字
                align: 'center', // 左右居中
                valign: 'middle' // 上下居中
            }, {
                field: 'name',
                title: '名称',
                align: 'center',
                valign: 'middle'
            }, {
                field: 'remark',
                title: '介绍',
                align: 'center',
                valign: 'middle'
            }, {
                title: "操作",
                align: 'center',
                valign: 'middle',
                width: 160, // 定义列的宽度，单位为像素px
                formatter:actionFormatter,
            }
        ],
        onLoadSuccess: function(){  //加载成功时执行
            console.info("加载成功");
        },
        onLoadError: function(){  //加载失败时执行
            console.info("加载数据失败");
        }

    })
    //操作栏的格式化
    function actionFormatter(value, row, index) {
        var id = value;
        var result = "";
        result += "<a href='/index/project/edit/id/" +row.id+ "' class='btn btn-xs blue' title='编辑'><span class='glyphicon glyphicon-pencil'></span></a>";
        result += "<a href='/index/project/delete/id/" +row.id+ "' class='btn btn-xs red' title='删除'><span class='glyphicon glyphicon-remove'></span></a>";
        return result;
    }
</script>

<!-- Bootstrap Js -->
<script src="/assets/component/strap-table/bootstrap-table.min.js"></script>
<script src="/assets/component/strap-table/bootstrap-table-zh-CN.min.js"></script>
<script src="/assets/component/strap-datetime/bootstrap-datetimepicker.min.js"></script>
<script src="/assets/js/jquery.metisMenu.js"></script>
<script src="/assets/materialize/js/materialize.min.js"></script>

<!-- Custom Js -->
<script src="/assets/js/custom-scripts.js"></script>
<script src="/assets/js/bootstrapValidator.min.js"></script>
<script src="/assets/js/layer/layer.js"></script>
</body>
</html>