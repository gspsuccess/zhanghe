<?php
//000000000000
 exit();?>
{"session_key":"UkXKw7qS5w8bGwDogv8G6g==","expires_in":7200,"openid":"okmkN0WYS0Ox9gHWVh1fCgOIRtm8","unionid":"oHTtqwSyAHSAoiPUL-OSI_FR6DKg","uid":"1","scope":16}