<?php

$arr = range(1,60);
$str = implode(',',$arr);

echo $str;