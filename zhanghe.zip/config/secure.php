<?php
/**
 * Created by PhpStorm.
 * User: gongs
 * Date: 2017/6/12
 * Time: 13:19
 */
return [
    'token_salt' => 'sfdfd2f5896DdfkadfFFAD5FD8FS2FD',
    'pay_back_url' => 'https://www.intelirri.com/api/v1/pay/notify'
];