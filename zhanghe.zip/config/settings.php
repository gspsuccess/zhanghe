<?php
/**
 * Created by PhpStorm.
 * User: gongs
 * Date: 2017/6/9
 * Time: 12:06
 * 自定义的网站地址信息
 */

return [
    'baseurl'=>'https://www.tongjie.com',
    //'baseurl'=>'http://www.tiebanss.com:8887',
    'imgPath'=>'/images/',
    'token_expire_in'=>7200,
    'api_expire_in'=>7200,
    'apiUrl'=>'http://www.tongjie.com/api/v1/',
];